﻿using UnityEngine;
using System.Collections;

public class MenuEffects : MonoBehaviour
{
	public enum EFFECT_STATUS
	{
		CBRUN,
		LBRUN,
		RBRUN,
		NONE
	}

	public static EFFECT_STATUS CURREFFECT_STATUS;

	private GameObject leftButton;
	private GameObject rightButton;
	private GameObject centralButton;

	private Color orange;
	private Color white;

	private int animateUseCounter;

	private void initGameObjects ()
	{
		centralButton = GameObject.FindGameObjectWithTag ("centralButton");
		leftButton = GameObject.FindGameObjectWithTag ("leftButton");
		rightButton = GameObject.FindGameObjectWithTag ("rightButton");
	}

	private void initEffectArtifacts ()
	{
		orange = new Color (253 / 255.0f, 186 / 255.0f, 41 / 255.0f);
		white = new Color (1, 1, 1);
		animateUseCounter = 0;
	}

	public static void setCurrentStatus (EFFECT_STATUS current_status)
	{
		CURREFFECT_STATUS = current_status;
	}

	private void centralButtonRun ()
	{
		int effect_time = 20;
		Color orange_changing = new Color (orange.r, orange.g, orange.b);
		orange_changing.r = orange.r + (white.r - orange.r) / effect_time * animateUseCounter;
		orange_changing.g = orange.g + (white.g - orange.g) / effect_time * animateUseCounter;
		orange_changing.b = orange.b + (white.b - orange.b) / effect_time * animateUseCounter;
		centralButton.GetComponent<SpriteRenderer> ().color = orange_changing;
		animateUseCounter++;
		if (animateUseCounter == effect_time) {
			centralButton.GetComponent<SpriteRenderer> ().color = white;
			animateUseCounter = 0;
			setCurrentStatus (EFFECT_STATUS.NONE);
		}
	}

	private void leftButtonRun ()
	{
		int effect_time = 20;
		Color orange_changing = new Color (orange.r, orange.g, orange.b);
		orange_changing.r = orange.r + (white.r - orange.r) / effect_time * animateUseCounter;
		orange_changing.g = orange.g + (white.g - orange.g) / effect_time * animateUseCounter;
		orange_changing.b = orange.b + (white.b - orange.b) / effect_time * animateUseCounter;
		leftButton.GetComponent<SpriteRenderer> ().color = orange_changing;
		animateUseCounter++;
		if (animateUseCounter == effect_time) {
			leftButton.GetComponent<SpriteRenderer> ().color = white;
			animateUseCounter = 0;
			setCurrentStatus (EFFECT_STATUS.NONE);
		}
	}

	private void rightButtonRun ()
	{
		int effect_time = 20;
		Color orange_changing = new Color (orange.r, orange.g, orange.b);
		orange_changing.r = orange.r + (white.r - orange.r) / effect_time * animateUseCounter;
		orange_changing.g = orange.g + (white.g - orange.g) / effect_time * animateUseCounter;
		orange_changing.b = orange.b + (white.b - orange.b) / effect_time * animateUseCounter;
		rightButton.GetComponent<SpriteRenderer> ().color = orange_changing;
		animateUseCounter++;
		if (animateUseCounter == effect_time) {
			rightButton.GetComponent<SpriteRenderer> ().color = white;
			animateUseCounter = 0;
			setCurrentStatus (EFFECT_STATUS.NONE);
		}
	}

	private void showEffectsLoop ()
	{
		switch (CURREFFECT_STATUS) {
		case EFFECT_STATUS.CBRUN:
			{
				Menu.setEffecting();
				centralButtonRun ();
				break;
			}
		case EFFECT_STATUS.LBRUN:
			{
				Menu.setEffecting();
				leftButtonRun ();
				break;
			}
		case EFFECT_STATUS.RBRUN:
			{
				Menu.setEffecting();
				rightButtonRun ();
				break;
			}
		case EFFECT_STATUS.NONE:
			{
				Menu.setNotEffecting();
				break;
			}
		default:
			{
				break;
			}
		}
	}
		
	void Awake(){
		initGameObjects ();
	}

	// Use this for initialization
	void Start ()
	{
		initEffectArtifacts ();
	}
	
	// Update is called once per frame
	void Update ()
	{
		showEffectsLoop ();
	}
}
