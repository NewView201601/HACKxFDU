﻿using UnityEngine;
using System.Collections;

public class Userpanel : MonoBehaviour
{

	// Use this for initialization
	void Start ()
	{
		//隐藏鼠标光标
		Cursor.visible = false;
	}

	// Update is called once per frame
	void Update ()
	{
		
	}
}