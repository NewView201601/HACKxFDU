﻿using UnityEngine;
using System.Collections;
using System.Threading;

public class Menu : MonoBehaviour
{
	private enum MENU_STATUS
	{
		NOMENU_ACTIVATED,
		MAINMENU_ACTIVATED,
		LEFTMENU_ACTIVATED,
		RIGHTMENU_ACTIVATED
	}

	private MENU_STATUS CURRENT_MENU_STATUS;

	private GameObject myCanvas;
	private GameObject myLeftCanvas;
	private GameObject myRightCanvas;
	private GameObject centralButton;
	private GameObject leftButton;
	private GameObject rightButton;


	private const bool UNACTIVE = false;
	private const bool ACTIVE = true;

	public static bool whether_effecting;

	private void initGameObjects ()
	{
		myCanvas = GameObject.FindGameObjectWithTag ("myCanvas");
		myLeftCanvas = GameObject.FindGameObjectWithTag ("leftCanvas");
		myRightCanvas = GameObject.FindGameObjectWithTag ("rightCanvas");
		centralButton = GameObject.FindGameObjectWithTag ("centralButton");
		leftButton = GameObject.FindGameObjectWithTag ("leftButton");
		rightButton = GameObject.FindGameObjectWithTag ("rightButton");
	}

	private void initMenuEffects ()
	{
		MenuEffects.setCurrentStatus (MenuEffects.EFFECT_STATUS.NONE);
		whether_effecting = false;
	}

	private void changeSTATUS (MENU_STATUS status)
	{
		CURRENT_MENU_STATUS = status;
	}

	private bool whetherSTATUS (MENU_STATUS status)
	{
		if (CURRENT_MENU_STATUS == status) {
			return true;
		}
		return false;
	}

	private void activate (GameObject g)
	{
		if (g.activeSelf == UNACTIVE) {
			g.SetActive (ACTIVE);
		}
	}

	private void unactivate (GameObject g)
	{
		if (g.activeSelf == ACTIVE) {
			g.SetActive (UNACTIVE);
		}
	}

	private void unactivateMainMenu ()
	{
		unactivate (myCanvas);
		unactivate (myLeftCanvas);
		unactivate (myRightCanvas);
	}

	private void activateMainMenu ()
	{
		activate (myCanvas);
		unactivate (myLeftCanvas);
		unactivate (myRightCanvas);
	}

	private void activateLeftMenu ()
	{
		activate (myCanvas);
		activate (myLeftCanvas);
		unactivate (myRightCanvas);
	}

	private void activateRightMenu ()
	{
		activate (myCanvas);
		unactivate (myLeftCanvas);
		activate (myRightCanvas);
	}

	public static void setEffecting ()
	{
		whether_effecting = true;
	}

	public static void setNotEffecting ()
	{
		whether_effecting = false;
	}


	public void updateMenu ()
	{
		switch (CURRENT_MENU_STATUS) {
		case MENU_STATUS.NOMENU_ACTIVATED:
			{
				if (KeyOperations.whetherClickedKey (KeyCode.M)) {
					changeSTATUS (MENU_STATUS.MAINMENU_ACTIVATED);
					activateMainMenu ();
					//特效效果
				}
				break;
			}
		case MENU_STATUS.MAINMENU_ACTIVATED:
			{
				if (MouseOperations.leftMouseClicked ()) {
					changeSTATUS (MENU_STATUS.LEFTMENU_ACTIVATED);
					activateLeftMenu ();
					//特效效果
					MenuEffects.setCurrentStatus (MenuEffects.EFFECT_STATUS.CBRUN);
				} else if (MouseOperations.rightMouseClicked ()) {
					changeSTATUS (MENU_STATUS.RIGHTMENU_ACTIVATED);
					activateRightMenu ();
					//特效效果
					MenuEffects.setCurrentStatus (MenuEffects.EFFECT_STATUS.CBRUN);
				} else if (KeyOperations.whetherClickedKey (KeyCode.M)) {
					changeSTATUS (MENU_STATUS.NOMENU_ACTIVATED);
					unactivateMainMenu ();
					//特效效果
				}
				break;
			}
		case MENU_STATUS.LEFTMENU_ACTIVATED:
			{
				if (MouseOperations.leftMouseClicked ()) {
					Debug.Log ("change style");
					//特效效果
					MenuEffects.setCurrentStatus (MenuEffects.EFFECT_STATUS.LBRUN);
				} else if (MouseOperations.rightMouseClicked ()) {
					changeSTATUS (MENU_STATUS.RIGHTMENU_ACTIVATED);
					activateRightMenu ();
					//特效效果
					MenuEffects.setCurrentStatus (MenuEffects.EFFECT_STATUS.CBRUN);
				} else if (KeyOperations.whetherClickedKey (KeyCode.M)) {
					changeSTATUS (MENU_STATUS.NOMENU_ACTIVATED);
					unactivateMainMenu ();
				}
				break;
			}
		case MENU_STATUS.RIGHTMENU_ACTIVATED:
			{
				if (MouseOperations.rightMouseClicked ()) {
					Debug.Log ("change color");
					//特效效果
					MenuEffects.setCurrentStatus (MenuEffects.EFFECT_STATUS.RBRUN);
				} else if (MouseOperations.leftMouseClicked ()) {
					changeSTATUS (MENU_STATUS.LEFTMENU_ACTIVATED);
					activateLeftMenu ();
					//特效效果
					MenuEffects.setCurrentStatus (MenuEffects.EFFECT_STATUS.CBRUN);
				} else if (KeyOperations.whetherClickedKey (KeyCode.M)) {
					changeSTATUS (MENU_STATUS.NOMENU_ACTIVATED);
					unactivateMainMenu ();
				}
				break;
			}
		default:
			{
				break;
			}
		}

	}

	void Awake(){
		initGameObjects ();
	}

	// Use this for initialization
	void Start ()
	{
		changeSTATUS (MENU_STATUS.NOMENU_ACTIVATED);
		unactivateMainMenu ();

		initMenuEffects ();
	}

	void Update ()
	{
		if (!whether_effecting) {
			updateMenu ();
		}
	}
}
