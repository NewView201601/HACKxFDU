﻿using UnityEngine;
using System.Collections;

public class MeshTest : MonoBehaviour
{
	public GameObject size_object;
	private bool whether_exit;

	Vector3 click_vertex;
	Vector3 stop_vertex;

	GameObject cube;

	private int counter;

	void Start(){
		counter=0;
		whether_exit=false;
		click_vertex=new Vector3(-0.5f,0.5f,0.5f);
		stop_vertex=new Vector3(1,1,1);
		cube= GameObject.CreatePrimitive(PrimitiveType.Cube);
	}

	private bool checkVector3Simbol(Vector3 v1,Vector3 v2){
		if(v1.x*v2.x>=0&&v1.y*v2.y>=0&&v1.z*v2.z>=0){
			return true;
		}
		return false;
	}

	void Update ()
	{
		if(whether_exit){
			return;
		}
		Vector3[] verteices=new Vector3[24];



		Vector3 current_vertex=new Vector3((click_vertex.x+0.1f*counter),(click_vertex.y+0.1f*counter),(click_vertex.z+0.1f*counter));

		counter++;


		Vector3 cube_position=cube.transform.position;
		Vector3 temp_position=new Vector3(click_vertex.x-cube_position.x,click_vertex.y-cube_position.y,click_vertex.z-cube_position.z);


		Mesh mesh=cube.GetComponent<MeshFilter>().mesh;
		verteices=mesh.vertices;

		for(int i=0;i<verteices.Length;i++){
			if(checkVector3Simbol(verteices[i],temp_position)){
				verteices[i]=current_vertex;
			}
		}
		mesh.vertices=verteices;
			

		if(counter==2000){
			whether_exit=true;
		}
	}
}