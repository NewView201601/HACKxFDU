﻿using UnityEngine;
using System.Collections;

public class BrushDraw : MonoBehaviour {
	

	private ArrayList types;
	private ArrayList colors;

	public GameObject pointer;

	private void initLists(){
		types=new ArrayList();
		types.Add(PrimitiveType.Cube);
		types.Add(PrimitiveType.Cylinder);
		types.Add(PrimitiveType.Capsule);
		types.Add(PrimitiveType.Sphere);

		colors=new ArrayList();
		colors.Add(Color.black);
		colors.Add(Color.blue);
		colors.Add(Color.cyan);
		colors.Add(Color.gray);
		colors.Add(Color.green);
		colors.Add(Color.red);
		colors.Add(Color.yellow);
	}
	// Use this for initialization
	void Start () {
		initLists();
	}

	private void drawCurrentModel(){
		PrimitiveType current_type=(PrimitiveType)types[0];
		Color current_color=(Color)colors[0];
		GameObject current_object = GameObject.CreatePrimitive(current_type);

		current_object.transform.localScale=pointer.transform.localScale;
		current_object.GetComponent<BoxCollider>().enabled=false;
		current_object.transform.position=pointer.transform.position;

		//current_object.GetComponent<>().color=current_color;
	}

	private void drawLoop(){
		if(Input.GetMouseButton(2)){
			drawCurrentModel();
		}
	}
	
	// Update is called once per frame
	void Update () {
		drawLoop();
	}
}
